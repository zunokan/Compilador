Seguem 2 exemplos da linguagem (arquivos do tipo .zuno) e 2 saídas esperadas ao fazer a geração de código (arquivos .c).

